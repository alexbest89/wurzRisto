from django.contrib import admin
from tavoli.models import Tavoli, Fornitore, Spec_Tav, Cameriere, Prodotti

admin.site.register(Tavoli)
admin.site.register(Fornitore)
admin.site.register(Spec_Tav)
admin.site.register(Cameriere)
admin.site.register(Prodotti)

