from django.apps import AppConfig


class TavoliConfig(AppConfig):
    name = 'tavoli'
